--
-- PostgreSQL database dump
--

\restrict oJMdmAJOKdbNOsrc26sT2I5qa3tyCobuYk3bRDo89YDx7LB4KGzAjAQFPPainnZ

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.items DROP CONSTRAINT IF EXISTS items_container_id_fkey;
ALTER TABLE IF EXISTS ONLY public.containers DROP CONSTRAINT IF EXISTS containers_location_id_fkey;
DROP TRIGGER IF EXISTS update_items_updated_at ON public.items;
DROP TRIGGER IF EXISTS update_containers_updated_at ON public.containers;
DROP INDEX IF EXISTS public.idx_items_name_description;
DROP INDEX IF EXISTS public.idx_items_name;
DROP INDEX IF EXISTS public.idx_items_container;
DROP INDEX IF EXISTS public.idx_containers_qr_code;
DROP INDEX IF EXISTS public.idx_containers_location;
DROP INDEX IF EXISTS public.idx_containers_description;
DROP INDEX IF EXISTS public.idx_containers_color;
ALTER TABLE IF EXISTS ONLY public.containers DROP CONSTRAINT IF EXISTS unique_color_number;
ALTER TABLE IF EXISTS ONLY public.locations DROP CONSTRAINT IF EXISTS locations_pkey;
ALTER TABLE IF EXISTS ONLY public.locations DROP CONSTRAINT IF EXISTS locations_name_key;
ALTER TABLE IF EXISTS ONLY public.items DROP CONSTRAINT IF EXISTS items_pkey;
ALTER TABLE IF EXISTS ONLY public.containers DROP CONSTRAINT IF EXISTS containers_qr_code_key;
ALTER TABLE IF EXISTS ONLY public.containers DROP CONSTRAINT IF EXISTS containers_pkey;
DROP TABLE IF EXISTS public.locations;
DROP TABLE IF EXISTS public.items;
DROP TABLE IF EXISTS public.containers;
DROP FUNCTION IF EXISTS public.update_updated_at_column();
DROP EXTENSION IF EXISTS "uuid-ossp";
--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: containers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.containers (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    qr_code character varying(50) NOT NULL,
    color character varying(50) NOT NULL,
    number integer NOT NULL,
    location_id uuid,
    location_text character varying(255),
    description text,
    photo_url character varying(500),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.containers OWNER TO postgres;

--
-- Name: items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    container_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    quantity integer DEFAULT 1,
    photo_url character varying(500),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.items OWNER TO postgres;

--
-- Name: locations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.locations OWNER TO postgres;

--
-- Data for Name: containers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.containers (id, qr_code, color, number, location_id, location_text, description, photo_url, created_at, updated_at) FROM stdin;
47cd5224-86ec-4f17-83bd-bfd5f631ce23	Red-01	Red	1	\N	\N	\N	\N	2026-01-18 23:13:23.318943	2026-01-18 23:13:23.318943
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.items (id, container_id, name, description, quantity, photo_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locations (id, name, description, created_at) FROM stdin;
e749f898-2030-4e0d-a47e-9729c77a06f6	Attic-Left	Left side of attic	2026-01-18 23:12:42.482465
bd8edc28-d489-4580-baef-466fb661abde	Attic-Right	Right side of attic	2026-01-18 23:12:42.482465
54e99ad0-1065-4462-8bd0-4540d2079592	Garage-A1	Garage section A, shelf 1	2026-01-18 23:12:42.482465
c54f430f-a785-474b-9d58-64766e330f4a	Garage-A2	Garage section A, shelf 2	2026-01-18 23:12:42.482465
121a6999-18c8-46a7-b4a6-893e71474395	Basement	Basement storage area	2026-01-18 23:12:42.482465
\.


--
-- Name: containers containers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.containers
    ADD CONSTRAINT containers_pkey PRIMARY KEY (id);


--
-- Name: containers containers_qr_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.containers
    ADD CONSTRAINT containers_qr_code_key UNIQUE (qr_code);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: locations locations_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_name_key UNIQUE (name);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: containers unique_color_number; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.containers
    ADD CONSTRAINT unique_color_number UNIQUE (color, number);


--
-- Name: idx_containers_color; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_containers_color ON public.containers USING btree (color);


--
-- Name: idx_containers_description; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_containers_description ON public.containers USING gin (to_tsvector('english'::regconfig, COALESCE(description, ''::text)));


--
-- Name: idx_containers_location; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_containers_location ON public.containers USING btree (location_id);


--
-- Name: idx_containers_qr_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_containers_qr_code ON public.containers USING btree (qr_code);


--
-- Name: idx_items_container; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_items_container ON public.items USING btree (container_id);


--
-- Name: idx_items_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_items_name ON public.items USING btree (name);


--
-- Name: idx_items_name_description; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_items_name_description ON public.items USING gin (to_tsvector('english'::regconfig, COALESCE((((name)::text || ' '::text) || description), ''::text)));


--
-- Name: containers update_containers_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_containers_updated_at BEFORE UPDATE ON public.containers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: items update_items_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_items_updated_at BEFORE UPDATE ON public.items FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: containers containers_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.containers
    ADD CONSTRAINT containers_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id) ON DELETE SET NULL;


--
-- Name: items items_container_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_container_id_fkey FOREIGN KEY (container_id) REFERENCES public.containers(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict oJMdmAJOKdbNOsrc26sT2I5qa3tyCobuYk3bRDo89YDx7LB4KGzAjAQFPPainnZ

